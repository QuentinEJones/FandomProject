<?php
$siteName = "Albion Onine Fandom & Stats Website ";
$mainNav = "<h3> <a href='/index.php'>Home</a> | <a href='/media.php'>Media</a> | <a href='/form.php'>Form</a> | <a href='/weaponStats.php'>Weapon Stats</a> | <a href='/armorStats.php'>Armor Stats</a> | <a href='/updates.php'>Game & Event Updates</a>  </h3>";
$footer = "copyright and contact info...";
?>